const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

let books = []; // Array che conterrà i libri nel database

// Array degli utenti registrati con le loro credenziali
const users = [
    { username: 'user1', password: 'password1' },
    { username: 'user2', password: 'password2' }
];

app.use(cors()); // Abilita il CORS per consentire richieste da altri domini
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Middleware per l'autenticazione dell'utente
function authenticateUser(req, res, next) {
    const { username, password } = req.body; // Estrae le credenziali dalla richiesta
    // Cerca un utente corrispondente nel database degli utenti
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        // Se l'utente è autenticato, aggiunge le informazioni sull'utente all'oggetto richiesta
        req.user = user;
        next(); // Passa il controllo alla prossima funzione di gestione della richiesta
    } else {
        // Se le credenziali sono errate, restituisce uno stato di errore 401 (Unauthorized)
        res.status(401).send('Authentication failed');
    }
}

// Rotta protetta che richiede autenticazione per aggiungere un libro
app.post('/book', authenticateUser, (req, res) => {
    const book = req.body; // Estrae il libro dalla richiesta
    books.push(book); // Aggiunge il libro al database
    res.send('Book is added to the database'); // Restituisce una conferma di successo
});

app.listen(port, () => console.log(`Hello world app listening on port ${port}!`));
